import React from "react";
import { Play, Pause, Square, Download, RefreshCw, Volume2, FastForward } from "lucide-react";

interface AudioVisualizerProps {
  lang: "en" | "ar";
  isPlaying: boolean;
  audioProgress: number;
  audioBuffer: AudioBuffer | null;
  playbackSpeed: number;
  onSpeedChange: (speed: number) => void;
  onTogglePlayback: () => void;
  onStopPlayback: () => void;
  onDownloadWav: () => void;
  pcmBase64: string | null;
  isGeneratingAudio: boolean;
  selectedVoice: string;
}

export const SPEED_PRESETS = [0.9, 1.0, 1.1, 1.15, 1.2, 1.25, 1.3];

export default function AudioVisualizer({
  lang,
  isPlaying,
  audioProgress,
  audioBuffer,
  playbackSpeed,
  onSpeedChange,
  onTogglePlayback,
  onStopPlayback,
  onDownloadWav,
  pcmBase64,
  isGeneratingAudio,
  selectedVoice
}: AudioVisualizerProps) {

  return (
    <div className="bg-neutral-950 rounded-2xl p-4.5 border border-rose-950/40 flex flex-col gap-4 shadow-xl">
      
      {/* Waveform visualizer */}
      <div className="flex flex-col gap-1.5">
        <div className="flex items-center justify-between text-xs text-neutral-400">
          <span className="font-semibold flex items-center gap-1.5">
            <span className={`w-2 h-2 rounded-full ${isPlaying ? "bg-emerald-500 animate-pulse" : "bg-rose-500"}`}></span>
            {isPlaying 
              ? (lang === "ar" ? `جاري الاستماع لـ ${selectedVoice}...` : `Listening to ${selectedVoice}...`) 
              : audioBuffer 
                ? (lang === "ar" ? "جاهز للتجربة والمخرجة" : "Ready to playback and tweak") 
                : (lang === "ar" ? "اضغط على توليد الصوت أعلاه للبدء" : "Synthesize the voice first above")}
          </span>
          <span className="font-mono text-[11px] bg-neutral-900 px-2 py-0.5 rounded text-neutral-300">
            {Math.round(audioProgress * 100)}%
          </span>
        </div>

        {/* Dynamic Faux Equalizer */}
        <div className="h-12 flex bg-neutral-900/60 rounded-xl overflow-hidden items-center px-4 gap-[3px] border border-neutral-900 relative">
          {Array.from({ length: 44 }).map((_, i) => {
            // High dynamic range on active playing, static otherwise
            const heightPercent = isPlaying 
              ? Math.sin(i * 0.25 + audioProgress * 32) * 55 + 50 
              : Math.abs(Math.sin(i * 0.15)) * 30 + 15;

            const isPassed = i / 44 <= audioProgress;

            return (
              <div
                key={i}
                className={`flex-1 transition-all duration-75 rounded-full ${
                  isPassed 
                    ? "bg-gradient-to-t from-rose-650 via-amber-500 to-amber-300" 
                    : "bg-neutral-800"
                }`}
                style={{ height: `${Math.max(4, Math.min(heightPercent, 95))}%` }}
              />
            );
          })}
        </div>
      </div>

      {/* Control Buttons (Play, Pause, Stop, Download) */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-neutral-900/40 p-3 rounded-xl border border-neutral-900">
        
        {/* Playback Actions group */}
        <div className="flex items-center gap-2.5 w-full sm:w-auto justify-center">
          <button
            onClick={onTogglePlayback}
            disabled={!audioBuffer}
            className={`w-11 h-11 rounded-full flex items-center justify-center transition-all cursor-pointer ${
              audioBuffer 
                ? "bg-amber-500 hover:bg-amber-400 text-neutral-950 shadow-md shadow-amber-500/10 hover:scale-105" 
                : "bg-neutral-800 text-neutral-600 cursor-not-allowed"
            }`}
            title={isPlaying ? "Pause" : "Play"}
          >
            {isPlaying ? <Pause className="w-5 h-5 stroke-[2.5]" /> : <Play className="w-5 h-5 stroke-[2.5] pr-0.5" />}
          </button>

          <button
            onClick={onStopPlayback}
            disabled={!audioBuffer}
            className={`w-11 h-11 rounded-full flex items-center justify-center transition-all cursor-pointer ${
              audioBuffer 
                ? "bg-neutral-800 hover:bg-neutral-700 text-neutral-300 border border-neutral-700 hover:scale-105" 
                : "bg-neutral-900 text-neutral-700 border border-neutral-950 cursor-not-allowed"
            }`}
            title="Stop Playback"
          >
            <Square className="w-4 h-4 fill-current" />
          </button>
        </div>

        {/* Real-time Web Audio Speed Control (Satisfies avoiding sounding "too heavy" or slow) */}
        <div className="flex flex-col gap-1.5 w-full sm:w-auto">
          <div className="flex items-center justify-between text-[11px] font-semibold text-neutral-400 select-none">
            <span className="flex items-center gap-1">
              <FastForward className="w-3 h-3 text-rose-500" />
              {lang === "ar" ? "سرعة الهضرة والتمبو (لمنع الثقل)" : "Speaking Tempo (Avoid heavy voice)"}
            </span>
            <span className="font-mono text-rose-400">{playbackSpeed}x</span>
          </div>

          <div className="flex flex-wrap gap-1 bg-neutral-950 p-1.5 rounded-lg border border-neutral-800/60 justify-center">
            {SPEED_PRESETS.map((speed) => (
              <button
                key={speed}
                onClick={() => onSpeedChange(speed)}
                disabled={!audioBuffer}
                className={`px-2 py-0.5 rounded text-[10px] font-bold transition-all cursor-pointer ${
                  playbackSpeed === speed
                    ? "bg-rose-500 text-white shadow-inner"
                    : audioBuffer 
                      ? "text-neutral-400 hover:text-white" 
                      : "text-neutral-700 cursor-not-allowed"
                }`}
              >
                {speed === 1.0 ? "1.0x (Normal)" : `${speed}x`}
              </button>
            ))}
          </div>
        </div>

        {/* WAV File Exporter download button */}
        <button
          onClick={onDownloadWav}
          disabled={!pcmBase64}
          className={`w-full sm:w-auto select-none font-bold text-xs px-4 py-2.5 rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer ${
            pcmBase64 
              ? "bg-rose-600 hover:bg-rose-500 text-white shadow-lg shadow-rose-950/20 active:scale-95" 
              : "bg-neutral-800 text-neutral-600 cursor-not-allowed border border-neutral-950"
          }`}
        >
          <Download className="w-4 h-4 text-white" />
          <span>{lang === "ar" ? "تحميل الملف الصوت الإشهاري" : "Download WAV Audio"}</span>
        </button>
      </div>

      <div className="text-[10px] leading-relaxed text-neutral-500 flex items-center gap-1.5 pt-0.5 dir-rtl text-right">
        <span>⭐ {lang === "ar" ? "المخرجة تلقائية تكتشف الحروف لتوليد طبقة صوت مغربية واضحة وسريعة ومميزة للتسويق." : "Synthesizer automatically optimizes pronunciations for Moroccan youth dialect."}</span>
      </div>

    </div>
  );
}
