import React from "react";
import { Sparkles, Sliders, Flame, RefreshCw } from "lucide-react";
import { MarketingTemplate } from "../types";

interface ScriptGeneratorProps {
  lang: "en" | "ar";
  productName: string;
  setProductName: (v: string) => void;
  productDesc: string;
  setProductDesc: (v: string) => void;
  tone: string;
  setTone: (v: string) => void;
  customDirectives: string;
  setCustomDirectives: (v: string) => void;
  includeFreeDelivery: boolean;
  setIncludeFreeDelivery: (v: boolean) => void;
  includeCashOnDelivery: boolean;
  setIncludeCashOnDelivery: (v: boolean) => void;
  includeUrgency: boolean;
  setIncludeUrgency: (v: boolean) => void;
  isGeneratingScript: boolean;
  onGenerateScript: () => void;
}

export default function ScriptGenerator({
  lang,
  productName,
  setProductName,
  productDesc,
  setProductDesc,
  tone,
  setTone,
  customDirectives,
  setCustomDirectives,
  includeFreeDelivery,
  setIncludeFreeDelivery,
  includeCashOnDelivery,
  setIncludeCashOnDelivery,
  includeUrgency,
  setIncludeUrgency,
  isGeneratingScript,
  onGenerateScript
}: ScriptGeneratorProps) {

  return (
    <div className="rounded-2xl border border-neutral-800 bg-neutral-900/60 p-5 lg:p-6 flex flex-col gap-5 shadow-inner" id="generator-workspace">
      <div className="border-b border-neutral-800 pb-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-amber-500" />
          <h3 className="font-bold text-neutral-200 text-sm">
            {lang === "ar" ? "معلومات الخدمة / المنتوج والصوت المطلوب" : "Campaign Script Details"}
          </h3>
        </div>
        <span className="text-[10px] text-amber-500 bg-amber-500/5 px-2 py-0.5 rounded font-bold uppercase tracking-wide">
          100% darija Marketing
        </span>
      </div>

      {/* Form Fields */}
      <div className="grid grid-cols-1 gap-4">
        <div>
          <label className="block text-xs font-semibold text-neutral-305 mb-1.5 flex items-center justify-between select-none">
            <span>{lang === "ar" ? "سمية الماركة أو الخدمة ديالك" : "Product / Service Brand Name"}</span>
            <span className="text-[10px] text-neutral-550">{lang === "ar" ? "بين قوسين لربطها بالصوت" : "Required"}</span>
          </label>
          <input
            id="input-product-name"
            type="text"
            value={productName}
            onChange={(e) => setProductName(e.target.value)}
            placeholder={lang === "ar" ? "مثال: بوتيك الأناقة، هامبرغر البنة، خدمات كليك..." : "e.g. Zaza Wear Clothing Brand"}
            className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-2.5 text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-all font-medium"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-neutral-305 mb-1.5 flex justify-between select-none">
            <span>{lang === "ar" ? "أهم تفاصيل ومزايا هاد العرض للشباب" : "Key Benefits (What triggers the buy?)"}</span>
            <span className="text-[10px] text-neutral-500">
              {lang === "ar" ? "للصوت ميزات كيوصفها" : "Features to emphasize"}
            </span>
          </label>
          <textarea
            id="input-product-desc"
            rows={3}
            value={productDesc}
            onChange={(e) => setProductDesc(e.target.value)}
            placeholder={lang === "ar" ? "مثال: تيشيرتات واسعة جودة عالية مخيطة ف كازا طبيعية مية فالمية مقاومة للتمدد وبثمن مناسب..." : "e.g. oversized cotton t-shirts Casablanca made best for summer..."}
            className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-2.5 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-all leading-relaxed"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-neutral-305 mb-1.5 select-none">
              {lang === "ar" ? "نبرة ومستوى الإقناع والإشهار" : "Ad Tone & Voice Appeal Style"}
            </label>
            <select
              id="select-tone"
              value={tone}
              onChange={(e) => setTone(e.target.value)}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-2.5 text-xs text-neutral-200 focus:outline-none focus:border-amber-500 transition-all font-medium"
            >
              <option value="Trendy & Youthful / Generation-Z (شبابي ومواكب للموضة ومؤثر)">
                {lang === "ar" ? "شبابي ومواكب للموضة ومؤثر (Z-Gen)" : "Youthful & Trendy (Z-Gen)"}
              </option>
              <option value="Energetic and Highly Persuasive (حماسي ومقنع للبيع السريع واللافت)">
                {lang === "ar" ? "حماسي جداً ومقنع (للإعلانات القوية)" : "Highly Energetic & Sales-Rich"}
              </option>
              <option value="Professional, Calm & Trustworthy (مهني، رصين دافيء وموثوق)">
                {lang === "ar" ? "مهني، رصين وموثوق (ستارت_اب/عقارات/تعليم)" : "Professional, Calm & Trustworthy"}
              </option>
              <option value="Humorous, Native and Storytelling (فكاهي، شعبي مبهج وقصصي)">
                {lang === "ar" ? "فكاهي، دارجة شعبية وقصصي بالكامل" : "Humorous Storyteller & Folk Darija"}
              </option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5 justify-between flex select-none">
              <span>{lang === "ar" ? "مصطلحات دارجة مغربية باغي تدخلها" : "Specific Moroccan Slangs / Keywords"}</span>
              <span className="text-[10px] text-amber-500">{lang === "ar" ? "اختياري" : "Optional"}</span>
            </label>
            <input
              id="input-custom-directives"
              type="text"
              value={customDirectives}
              onChange={(e) => setCustomDirectives(e.target.value)}
              placeholder={lang === "ar" ? "مثال: هربان، ناضي، مكاينش اللعب، الهمزة..." : "e.g. nady, harban, makaynach tamara..."}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-2.5 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-all font-medium"
            />
          </div>
        </div>
      </div>

      {/* Quick Toggle Psychological Triggers widget */}
      <div className="bg-neutral-950 rounded-xl p-4 border border-neutral-850 flex flex-col gap-3">
        <span className="text-[11px] font-bold tracking-wider text-neutral-400 bg-neutral-950/50 px-2 py-1 rounded inline-block w-fit uppercase">
          🔥 {lang === "ar" ? "محفزات إقناع مدمجة لإزالة المخاوف لشراء الشباب" : "Moroccan Consumer Conversion Multipliers"}
        </span>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <label className="flex items-center gap-3 bg-neutral-900/50 hover:bg-neutral-900 p-2.5 rounded-lg border border-neutral-800/80 cursor-pointer select-none transition-all">
            <input
              type="checkbox"
              checked={includeFreeDelivery}
              onChange={(e) => setIncludeFreeDelivery(e.target.checked)}
              className="rounded border-neutral-800 text-amber-500 focus:ring-amber-500 bg-neutral-950 w-4 h-4 accent-amber-500"
            />
            <div className="flex flex-col">
              <span className="text-xs font-semibold text-neutral-205">{lang === "ar" ? "التوصيل فابور" : "Livraison Gratuite"}</span>
              <span className="text-[10px] text-amber-500/80">{lang === "ar" ? "اربح ثقة الزبون" : "Free Delivery"}</span>
            </div>
          </label>

          <label className="flex items-center gap-3 bg-neutral-900/50 hover:bg-neutral-900 p-2.5 rounded-lg border border-neutral-800/80 cursor-pointer select-none transition-all">
            <input
              type="checkbox"
              checked={includeCashOnDelivery}
              onChange={(e) => setIncludeCashOnDelivery(e.target.checked)}
              className="rounded border-neutral-800 text-amber-500 focus:ring-amber-500 bg-neutral-950 w-4 h-4 accent-amber-500"
            />
            <div className="flex flex-col">
              <span className="text-xs font-semibold text-neutral-205">{lang === "ar" ? "خلص ف الباب" : "Paiement à la porte"}</span>
              <span className="text-[10px] text-amber-500/80">{lang === "ar" ? "دفع عند الاستلام" : "Cash on Delivery"}</span>
            </div>
          </label>

          <label className="flex items-center gap-3 bg-neutral-900/40 hover:bg-neutral-905 p-2.5 rounded-lg border border-neutral-800/80 cursor-pointer select-none transition-all">
            <input
              type="checkbox"
              checked={includeUrgency}
              onChange={(e) => setIncludeUrgency(e.target.checked)}
              className="rounded border-neutral-850 text-amber-505 focus:ring-amber-500 bg-neutral-950 w-4 h-4 accent-amber-500"
            />
            <div className="flex flex-col">
              <span className="text-xs font-semibold text-neutral-250">{lang === "ar" ? "همزة اليوم فقط" : "Limited stock promo"}</span>
              <span className="text-[10px] text-rose-500">{lang === "ar" ? "الكمية المحدودة والوقت" : "Urgency trigger"}</span>
            </div>
          </label>
        </div>
      </div>

      {/* Generate Script Command */}
      <button
        id="btn-generate-script-comp"
        onClick={onGenerateScript}
        disabled={isGeneratingScript || !productName.trim()}
        className="w-full mt-1 cursor-pointer bg-gradient-to-r from-amber-500 via-amber-600 to-rose-600 hover:from-amber-600 hover:to-rose-700 text-neutral-950 font-extrabold text-sm py-3.5 px-6 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-amber-950/25 active:scale-[0.99] transition-all disabled:opacity-40 disabled:cursor-not-allowed"
      >
        {isGeneratingScript ? (
          <>
            <RefreshCw className="w-4 h-4 animate-spin text-neutral-950" />
            <span>{lang === "ar" ? "جاري التفكير وصياغة سيناريو إشهاري ممتع..." : "Crafting your premium script copy in Moroccan Darija..."}</span>
          </>
        ) : (
          <>
            <Sparkles className="w-4.5 h-4.5 stroke-[2.5]" />
            <span>
              {lang === "ar" 
                ? "ولّد دابا سيناريو إعلاني رائع بالدارجة ✍️" 
                : "Generate Conversion Script in Dialect"}
            </span>
          </>
        )}
      </button>
    </div>
  );
}
