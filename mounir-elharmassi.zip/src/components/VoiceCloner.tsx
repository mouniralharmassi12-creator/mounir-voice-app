import React, { useState, useRef } from "react";
import { 
  Sparkles, 
  Upload, 
  Mic, 
  Square, 
  Link2, 
  Check, 
  Trash2, 
  Activity, 
  Music,
  Maximize2,
  Info,
  Loader2,
  AlertCircle
} from "lucide-react";
import { VoiceProfile } from "../types";

interface VoiceClonerProps {
  lang: "en" | "ar";
  onCloneCreated: (newVoice: VoiceProfile) => void;
  activeClones: VoiceProfile[];
  onDeleteClone: (id: string) => void;
}

export default function VoiceCloner({ lang, onCloneCreated, activeClones, onDeleteClone }: VoiceClonerProps) {
  const [cloneName, setCloneName] = useState("");
  const [socialLink, setSocialLink] = useState("");
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [recordedBlob, setRecordedBlob] = useState<Blob | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [clonedSpecs, setClonedSpecs] = useState<{
    gender: "Male" | "Female";
    pace: "Fast & Light" | "Conversational" | "Smooth & Calm";
    pitch: "Slightly High" | "Medium" | "Warm & Deep";
    energy: "High Engagement (Marketing)" | "Inspirational" | "Promo Direct Sale";
  } | null>(null);

  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // Toggle simulation for direct link parsing/guessing
  const handleLinkPaste = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSocialLink(e.target.value);
    if (!cloneName) {
      if (e.target.value.includes("instagram.com")) {
        setCloneName(lang === "ar" ? "صوت مستنسخ من إنستغرام" : "Instagram Reel Clone");
      } else if (e.target.value.includes("tiktok.com")) {
        setCloneName(lang === "ar" ? "صوت مستنسخ من تيك توك" : "TikTok Creator Clone");
      } else {
        setCloneName(lang === "ar" ? "مستنسخ صوتي شخصي" : "Custom Social Clone");
      }
    }
  };

  // Drag and drop audio files
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setAudioFile(file);
      if (!cloneName) {
        setCloneName(file.name.split(".")[0].substring(0, 20) + " (Clone)");
      }
    }
  };

  // Recording audio locally
  const startRecording = async () => {
    setErrorMsg(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: "audio/webm" });
        setRecordedBlob(audioBlob);
        if (!cloneName) {
          setCloneName(lang === "ar" ? "تسجيل ميكروفون مستنسخ" : "My Mic Voice Clone");
        }
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err: any) {
      setErrorMsg(lang === "ar" ? "تعذر الوصول للميكروفون. يرجى تفعيل الصلاحية." : "Microphone access denied. Please enable browser permissions.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      // Stop all tracks to release resource
      mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
    }
  };

  // Trigger clone analysis to formulate custom system prompt for prebuilt voices
  const handleStartCloning = async () => {
    if (!cloneName.trim()) {
      setErrorMsg(lang === "ar" ? "يرجى كتابة اسم الصوت المستنسخ." : "Please write a name for your custom cloned voice.");
      return;
    }
    if (!audioFile && !socialLink && !recordedBlob) {
      setErrorMsg(lang === "ar" ? "يرجى تحميل ملف صوتي، لصق رابط ريلز، أو التسجيل مباشرة من الميكروفون." : "Please provide an audio sample: upload a file, paste a link, or record your voice.");
      return;
    }

    setIsAnalyzing(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    // Simulated parsing logic that analyzes features of social link / file and formats them
    setTimeout(() => {
      // Create rich vocal characteristics based on options
      const isFemalePreset = cloneName.toLowerCase().includes("girl") || cloneName.toLowerCase().includes("she") || cloneName.includes("كنزة") || cloneName.includes("ياسمين") || socialLink.includes("beauty") || Math.random() > 0.5;
      
      const parsedSpecs = {
        gender: (isFemalePreset ? "Female" : "Male") as "Male" | "Female",
        pace: "Fast & Light" as "Fast & Light" | "Conversational" | "Smooth & Calm", // Marketing demands faster rhythm
        pitch: (isFemalePreset ? "Slightly High" : "Warm & Deep") as "Slightly High" | "Medium" | "Warm & Deep",
        energy: "High Engagement (Marketing)" as "High Engagement (Marketing)" | "Inspirational" | "Promo Direct Sale"
      };

      setClonedSpecs(parsedSpecs);

      // Create a customized voice profile implementing the requested speaking speed, light/non-heavy signature, and local Darija expressions
      const baseVoiceModel = parsedSpecs.gender === "Female" ? "Zephyr" : "Kore";
      
      const newClone: VoiceProfile = {
        id: `clone_${Date.now()}`,
        name: `${cloneName} ✨`,
        nameAr: `${cloneName} ✨ (مستنسخ)`,
        gender: parsedSpecs.gender,
        tag: lang === "ar" ? "مستنسخ احترافي" : "Custom Clone",
        accent: lang === "ar" ? "مستنسخ من المصدر" : "Cloned Accent DNA",
        accentAr: "بصمة صوتية مطابقة",
        description: `Social-audio clone emulating a ${parsedSpecs.gender} voice. Speeds: fast, light-toned, optimized for high sales conversion.`,
        descriptionAr: `نسخة مستنسخة مطابقة للبصمة الصوتية لصاحب المحتوى. سريعة، رنانة، وغير ثقيلة وممتازة للتسويق.`,
        baseVoice: baseVoiceModel,
        systemTonePrompt: `You are cloned voice of '${cloneName}'. Read with an authentic Moroccan Arabic (Darija) accent. Speak beautifully, with high-converting marketing precision. Crucially, speak slightly fast, extremely light and airy, avoiding any heavy or rhythmic robotic chanting. Emulate a trendy social media content creator or high-tempo radio ad voice.`,
        isClone: true,
        cloneSource: socialLink ? "Social Link" : (audioFile ? "Uploaded File" : "Microphone Record")
      };

      onCloneCreated(newClone);
      setIsAnalyzing(false);
      setSuccessMsg(
        lang === "ar" 
          ? `رائع! تم استخلاص تلاوين الصوت وحفظ النسخة باسم "${cloneName}" في قائمة المعلقين.` 
          : `Amazing! Cloned voice DNA extracted. "${cloneName}" is now available in your Voice Actor list.`
      );

      // Reset fields
      setSocialLink("");
      setAudioFile(null);
      setRecordedBlob(null);
    }, 2500);
  };

  return (
    <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 flex flex-col gap-4 relative overflow-hidden" id="voice-cloner-lab">
      {/* Visual neon badge */}
      <div className="absolute top-0 right-0 -mt-6 -mr-6 w-24 h-24 bg-rose-500 rounded-full blur-3xl opacity-10 pointer-events-none"></div>

      <div className="border-b border-neutral-800 pb-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Activity className="w-5 h-5 text-rose-500" />
          <h3 className="font-bold text-[14px] text-neutral-100 uppercase tracking-widest">
            {lang === "ar" ? "رادار استنساخ وتطويع الأصوات (Cloning Lab)" : "Social Media Voice Cloner Lab"}
          </h3>
        </div>
        <span className="text-[9px] bg-rose-500/15 text-rose-400 border border-rose-500/20 font-bold px-2 py-0.5 rounded tracking-wider uppercase">
          {lang === "ar" ? "استنساخ ريلز وتيك توك" : "High Authenticity"}
        </span>
      </div>

      <p className="text-xs text-neutral-400 leading-relaxed">
        {lang === "ar" 
          ? "عندك شي صوت تيك توك ولا إعلان انستغرام عاجبك؟ دابا تقدر تنسخ الطبقة والنبرة ديالو! سجل صوتك، حمل ملف، ولا كولي رابط لافيديو وغادي نخرجو البصمة الصوتية ديالو باش نولدو بيها السيناريو الجديد."
          : "Love a specific creator's voice from TikTok or Instagram Reels? Copy their signature style! Upload audio, paste a link, or record with your mic. We emulate their speed, tone, and Moroccan dialect details instantly."}
      </p>

      {/* Cloning Sources Inputs */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-1">
        
        {/* Step A: Custom Label Name */}
        <div className="md:col-span-2 flex flex-col gap-1.5">
          <label className="text-xs font-semibold text-neutral-300">
            {lang === "ar" ? "1. اعطي اسماً لهذا المستنسخ الصوتي" : "1. Label your cloned voice model"}
          </label>
          <input
            id="input-clone-name"
            type="text"
            value={cloneName}
            onChange={(e) => setCloneName(e.target.value)}
            placeholder={lang === "ar" ? "مثال: صوت فتاة التجميل المؤثرة، أو صوت سعد التسويقي" : "e.g. Beauty Creator Cloned Speaker"}
            className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-2 text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-rose-500 focus:ring-1 focus:ring-rose-500 transition-all font-medium"
          />
        </div>

        {/* Option 2a: Link input */}
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-semibold text-neutral-300 flex items-center gap-1">
            <Link2 className="w-3.5 h-3.5 text-rose-400" />
            <span>{lang === "ar" ? "الخيار أ: رابط إشهار أو ريلز" : "Option A: Paste Social Media URL"}</span>
          </label>
          <input
            id="input-social-link"
            type="text"
            value={socialLink}
            onChange={handleLinkPaste}
            placeholder={lang === "ar" ? "انستغرام ريلز، تيك توك، إلخ..." : "https://instagram.com/reels/..."}
            className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-2 text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-rose-500 transition-all font-medium"
          />
        </div>

        {/* Option 2b: File uploader or Mic recorder */}
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-semibold text-neutral-300">
            {lang === "ar" ? "الخيار ب: تسجيل بالميك أو تحميل ملف" : "Option B: Record Mic or Upload Audio"}
          </label>
          
          <div className="flex gap-2">
            {/* Record toggler */}
            <button
              onClick={isRecording ? stopRecording : startRecording}
              className={`flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                isRecording 
                  ? "bg-rose-500 text-white border-rose-400 animate-pulse" 
                  : "bg-neutral-950 text-neutral-300 border-neutral-800 hover:border-neutral-700"
              }`}
            >
              <Mic className="w-3.5 h-3.5" />
              <span>
                {isRecording 
                  ? (lang === "ar" ? "توقف وطابق" : "Stop") 
                  : recordedBlob 
                    ? (lang === "ar" ? "تعديل التسجيل 🎙️" : "Re-record") 
                    : (lang === "ar" ? "تسجيل المايك 🎙️" : "Record Mic")}
              </span>
            </button>

            {/* File uploader trigger */}
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-neutral-950 text-neutral-300 border border-neutral-800 hover:border-neutral-700 transition-all cursor-pointer text-ellipsis overflow-hidden whitespace-nowrap"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>
                {audioFile ? audioFile.name.substring(0, 15) : (lang === "ar" ? "رفع ملف صوتي" : "Upload File")}
              </span>
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="audio/*"
              onChange={handleFileChange}
              className="hidden"
            />
          </div>
        </div>
      </div>

      {/* Trigger Processing Button */}
      <button
        id="btn-process-clone"
        onClick={handleStartCloning}
        disabled={isAnalyzing || (!socialLink && !audioFile && !recordedBlob)}
        className="w-full mt-1 cursor-pointer bg-rose-600 hover:bg-rose-500 text-white rounded-xl py-3 text-xs font-extrabold flex items-center justify-center gap-2 shadow-lg disabled:opacity-50 transition-all active:scale-[0.99]"
      >
        {isAnalyzing ? (
          <>
            <Loader2 className="w-4 h-4 animate-spin text-white" />
            <span>{lang === "ar" ? "جاري سحب البصمة وتحليل طبقات الصوت من المصدر..." : "Analyzing speech characteristics & speed ratios..."}</span>
          </>
        ) : (
          <>
            <Sparkles className="w-4 h-4" />
            <span>
              {lang === "ar" 
                ? "ابدأ استنساع الصوت وحفظ البصمة" 
                : "Analyze & Extract Custom Cloned Voice"}
            </span>
          </>
        )}
      </button>

      {/* Notifications and feedback inside component */}
      {errorMsg && (
        <div className="bg-rose-500/10 border border-rose-500/10 p-3 rounded-lg flex items-center gap-2 text-[11px] text-rose-300 animate-fadeIn">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {successMsg && (
        <div className="bg-emerald-500/10 border border-emerald-500/20 p-3 rounded-lg flex items-center gap-2 text-[11px] text-emerald-300 animate-fadeIn">
          <Check className="w-4 h-4 shrink-0 text-emerald-400" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Display Registered Clones in Cloned panel list */}
      {activeClones.length > 0 && (
        <div className="mt-2 pt-3 border-t border-neutral-800/80">
          <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-2">
            🏷️ {lang === "ar" ? "الأصوات المستنسخة النشطة المتوفرة" : "Your Cloned Voice Profiles Directory"}
          </span>

          <div className="flex flex-col gap-2">
            {activeClones.map((cln) => (
              <div
                key={cln.id}
                className="flex items-center justify-between p-2.5 rounded-lg bg-neutral-950 border border-rose-950/40"
              >
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded bg-rose-500/10 flex items-center justify-center text-xs text-rose-400 font-bold">
                    👥
                  </div>
                  <div>
                    <span className="text-xs font-bold text-neutral-100 block">{lang === "ar" ? cln.nameAr : cln.name}</span>
                    <span className="text-[9px] text-rose-500 font-semibold uppercase tracking-wider block">
                      {cln.gender === "Female" ? (lang === "ar" ? "أنثى • سريع وخفيف" : "Female • Fast & Light") : (lang === "ar" ? "ذكر • سريع ورنان" : "Male • Fast & Rich")}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <span className="text-[10px] text-rose-400 bg-rose-500/5 px-1.5 py-0.5 rounded italic">
                    {cln.cloneSource}
                  </span>
                  <button
                    onClick={() => onDeleteClone(cln.id)}
                    className="p-1 text-neutral-500 hover:text-rose-500 transition-colors cursor-pointer"
                    title={lang === "ar" ? "حذف البصمة" : "Delete Cloned Model"}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
