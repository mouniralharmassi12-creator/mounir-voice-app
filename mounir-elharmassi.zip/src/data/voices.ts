import { VoiceProfile, MarketingTemplate } from "../types";

export const MOROCCAN_VOICE_MODELS: VoiceProfile[] = [
  // --- Female Profiles (8) ---
  {
    id: "yasmine",
    name: "Yasmine",
    nameAr: "ياسمين (الدارجة الشابة)",
    gender: "Female",
    tag: "Casual & Trendy",
    accent: "Casablanca Youth",
    accentAr: "شباب الدار البيضاء",
    description: "Ultra-natural girl influencer, speaks fast with cool Moroccan slangs. Ideal for trendy clothing, lifestyle products, and social media reels.",
    descriptionAr: "مؤثرة شابة طبيعية، كتكلم بسرعة وحيوية بأسلوب إنستغرامي وتيك توك. ممتاز لملابس الشباب، الماكياج، والمنتجات العصرية.",
    baseVoice: "Zephyr",
    systemTonePrompt: "Read cheerfully and slightly fast like a trendy Casablanca female influencer in Moroccan Darija. Keep it extremely natural, highly youthful, and casual. Emphasize active lifestyle verbs."
  },
  {
    id: "kenza",
    name: "Kenza",
    nameAr: "كنزة (أناقة الرباط)",
    gender: "Female",
    tag: "Premium & Cosmetics",
    accent: "Elegant Rabat",
    accentAr: "لهجة الرباط الأنيقة",
    description: "Warm, soft, and highly seductive commercial voice. Speaks with premium clarity. Excellent for skincare, beauty ads, and luxury local brands.",
    descriptionAr: "صوت ناعم، واثق وأنيق بزاف، طريقة الكلام دياله دافئة وجذابة. ممتاز للمستحضرات التجميلية، لبراندات النخبة، والصالونات الراقية.",
    baseVoice: "Zephyr",
    systemTonePrompt: "Read with a natural female voice, warm, confident, and highly persuasive marketing tone in Moroccan Darija. Speak clearly, slightly fast and fluidly, expressive like a luxury beauty advertisement."
  },
  {
    id: "salma",
    name: "Salma",
    nameAr: "سلمى (البهجة والنشاط)",
    gender: "Female",
    tag: "Friendly & Warm",
    accent: "Marrakesh Warm",
    accentAr: "لهجة مراكش المضيافة",
    description: "Extremely welcoming and warm voice, full of hospitality. Sounds conversational like your favorite local friend recommending a food spot.",
    descriptionAr: "صوت بشوش، مرح كلو بهجة وترحاب مراكشي أصيل. كتكلم بطريقة ودية بحال صاحبتك لي كتعاود ليك على أحسن بلاصة تاكل فيها.",
    baseVoice: "Puck",
    systemTonePrompt: "Speak with high warmth, friendly laughter, and open Moroccan hospitality. Keep it conversational, down-to-earth, and lively."
  },
  {
    id: "sara",
    name: "Sara",
    nameAr: "سارة (أناقة الشمال)",
    gender: "Female",
    tag: "High Tempos Ad",
    accent: "Northern Chamal",
    accentAr: "لهجة الشمال المميزة",
    description: "High-octane energetic voice with the charming accent of Tangier/Tetouan. Speaks with quick rhythm and delightful promotional energy.",
    descriptionAr: "صوت كرمش بالنشاط بلكنة طنجاوية/تطوانية روعة. سريعة فالهضرة وممتازة للتخفيضات السريعة والعروض الصيفية.",
    baseVoice: "Zephyr",
    systemTonePrompt: "Read with a light, fast northern Moroccan (Chamal) feminine rhythm. Focus on dynamic emphasis of promotional offers and immediate discount calls-to-action."
  },
  {
    id: "malak",
    name: "Malak",
    nameAr: "ملاك (رائدة الأعمال)",
    gender: "Female",
    tag: "Corporate Tech",
    accent: "Modern Professional",
    accentAr: "لهجة مهنية معاصرة",
    description: "Educated, very confident, and structured professional. Perfect for academies, web agencies, SaaS applications, and e-learning programs.",
    descriptionAr: "صوت رزين، واثق من نفسو وقارئ بطريقة منظمة وبأسلوب مقنع. ممتاز للماتارس الخاصة، تطبيقات الهواتف، وخدمات المقاولات.",
    baseVoice: "Charon",
    systemTonePrompt: "Speak clearly, professionally, and persuasively in standard Moroccan Darija. Use a tone that inspires trust, digital empowerment, and local innovation."
  },
  {
    id: "ghita",
    name: "Ghita",
    nameAr: "غيثة (صوت تيك توك)",
    gender: "Female",
    tag: "Hyper-Fast Viral",
    accent: "Viral Audio Vibe",
    accentAr: "لهجة السوشل ميديا السريعة",
    description: "Extremely snappy, high-pitched female voice tailored for viral 15-second ads. Keeps viewers hooked with every word. Highly engaging.",
    descriptionAr: "صوت سريع بزاف وحماسي ديال فيديوهات السوشل ميديا القصيرة. غاتخلي المتفرج يكمل الفيديو حتى للآخر من اللحظة الأولى.",
    baseVoice: "Zephyr",
    systemTonePrompt: "Speak very fast, extremely punchy, with high enthusiasm. Exaggerate emotional expressions and native Moroccan slang triggers. Perfect for a 15-second digital reel."
  },
  {
    id: "farah",
    name: "Farah",
    nameAr: "فرح (العروض والاقتصاد)",
    gender: "Female",
    tag: "Retail & Promos",
    accent: "Friendly Standard",
    accentAr: "دارجة مبسطة للعموم",
    description: "Cheerful retail specialist. Sounds like she's announcing a great deal to families. Highly effective for local e-commerce stores.",
    descriptionAr: "صوت بشوش ومحبوب عند العائلات والعموم. كيبان بحال شي وحدة كتشارك همزة زوينة مع صحاباتها. مناسب جداً للمتاجر المحلية وعروض العيد.",
    baseVoice: "Puck",
    systemTonePrompt: "Speak cheerfully with standard clear Moroccan Arabic. Maintain a warm promotional family-friendly retail announcement vibe."
  },
  {
    id: "chaimae",
    name: "Chaimae",
    nameAr: "شيماء (حديث دافئ)",
    gender: "Female",
    tag: "Podcast & Trust",
    accent: "Deep Smooth",
    accentAr: "صوت إذاعي دافئ عميق",
    description: "Slightly deeper, serene, and incredibly soothing female tone. Excellent for storytelling, premium products, and brand heritage narration.",
    descriptionAr: "صوتإذاعي رنان، دافئ ومريح للأذن. هادئ وفي نفس الوقت كيوحي بالثقة الكبيرة. صالحة للمنتجات الطبيعية، المنتوجات التقليدية والرواية.",
    baseVoice: "Puck",
    systemTonePrompt: "Speak with a deep, soothing and very clear feminine Moroccan Arabic tone. Give natural breathing pauses but maintain persuasive momentum."
  },

  // --- Male Profiles (7) ---
  {
    id: "amine",
    name: "Amine",
    nameAr: "أمين (الأنشط والشبابي)",
    gender: "Male",
    tag: "Cool Gen-Z Male",
    accent: "Casablanca Urban",
    accentAr: "دارجة كازا الحركية",
    description: "Modern young Moroccan influencer. Energetic, fast and conversational. Best for sneakers, accessories, gym programs, and fast-food deals.",
    descriptionAr: "مؤثر مغربي كازاوي بامتياز الحيوية، خفيف فالهضرة وكيستعمل الدارجة دالزنقة لي عاجبة للشباب. مناسب للسبرديلات، الفاست فود والجيمنغ.",
    baseVoice: "Kore",
    systemTonePrompt: "In Moroccan Darija, read like an energetic local streetwear store owner or young TikTok influencer. Speak slightly fast, with punchy modern tones, avoiding heavy formal Arabic cadence."
  },
  {
    id: "saad",
    name: "Saad",
    nameAr: "سعد (صوت إشهاري قوي)",
    gender: "Male",
    tag: "High Impact Ads",
    accent: "Dynamic Direct Sale",
    accentAr: "صوت هجومي للبيع السريع",
    description: "Highly energetic, direct and persuasive. Speaks with immense marketing authority. Perfect for time-limited sales, and direct response ads.",
    descriptionAr: "صوت قوي وإشهاري كيجذب الانتباه بزاف. مناسب للبيع السريع والهميزات لي مساليين اليوم. كيكلم المستهلك نيشان بحماس عالي.",
    baseVoice: "Fenrir",
    systemTonePrompt: "Adopt an intensely persuasive, energetic, and highly professional direct sales tone in Moroccan Darija. Voice must feel extremely active, fast, and light, urging immediate action."
  },
  {
    id: "youssef",
    name: "Youssef",
    nameAr: "يوسف (البهجة المراكشية)",
    gender: "Male",
    tag: "Friendly Storyteller",
    accent: "Marrakesh Comedian",
    accentAr: "البهجة المراكشية الشعبية",
    description: "Warm, witty and cheerful male voice with Marrakesh flavor. Keeps your audience smiling while presenting top features naturally.",
    descriptionAr: "صوت مراكشي حركي كلو ضحك ونشاط. كيخلي الكليان فرحان وكيركز على البنة والجودة بطريقة مضحكة وشعبية ومألوفة.",
    baseVoice: "Puck",
    systemTonePrompt: "Read with playful Moroccan humor and hospitable warmth. Focus on friendly storytelling, speaking in an upbeat, lightning-fast lighthearted tone."
  },
  {
    id: "mehdi",
    name: "Mehdi",
    nameAr: "المهدي (الأنيق الهادئ)",
    gender: "Male",
    tag: "Premium Consultant",
    accent: "Modern Educated",
    accentAr: "لهجة النخبة المثقفة",
    description: "Smooth, trustworthy, professional voice. Sounds like a successful digital marketing consultant or property broker. Ideal for real estate, cars, and premium services.",
    descriptionAr: "صوت هادئ، نقي ومألوف عند الكليان الكبار. كيبان بحال مستشار عقاري ناجح أو بايع سيارات فخمة. يعطي قيمة تلميعية للبراند ديالك.",
    baseVoice: "Charon",
    systemTonePrompt: "Speak in fluid, clear, elegant Moroccan Darija. Tone should be professional, reassuring, confident, with smooth pacing perfect for premium client segments."
  },
  {
    id: "anass",
    name: "Anass",
    nameAr: "أنس (مراجعات الفيديو)",
    gender: "Male",
    tag: "Tech Reviewer",
    accent: "Fast Gadget Geek",
    accentAr: "مراجعة الهواتف والأجهزة",
    description: "Fast-talking, analytical and passionate about technology. Ideal for smartphones, headsets, setup updates, and smart gadgets.",
    descriptionAr: "خفيف فالهضرة، كيتكلم بحماس على التكنولوجيا والجديد دالسوق. كيبان متمكن وفنفس الوقت واصل للشباب بطريقة سهلة ومجربة.",
    baseVoice: "Kore",
    systemTonePrompt: "Adopt a enthusiastic, analytical, fast-paced Moroccan tech reviewer tone. Emphasize product features, specs, and price-to-value propositions."
  },
  {
    id: "reda",
    name: "Reda",
    nameAr: "رضا (بساطة شعبية)",
    gender: "Male",
    tag: "Humble Local Vibe",
    accent: "Beldi Traditional",
    accentAr: "دارجة بلدية مألوفة",
    description: "Friendly, direct, and down-to-earth neighborhood merchant style. Appeals deeply to standard Moroccan families and traditional shoppers.",
    descriptionAr: "صوت بلدي، حنين ومحبوب بحال الدري دالحومة لي كلو أمانة. مناسب لبيع زيت العود، العسل الحر، المنتجات التقليدية، ومحلات المأكولات الشعبية.",
    baseVoice: "Puck",
    systemTonePrompt: "Speak in warm, beldi, humble traditional Moroccan accent. Maintain an honest, authentic, and calm neighborhood tone."
  },
  {
    id: "hamza",
    name: "Hamza",
    nameAr: "حمزة (مغامرة وقوة)",
    gender: "Male",
    tag: "Deep Intense Ad",
    accent: "Bold Sporty",
    accentAr: "لهجة القوة والمغامرة",
    description: "Deep, epic, and highly motivational voice. Ideal for fitness centers, car rentals, adventure accessories, energy drinks, and gaming launches.",
    descriptionAr: "صوت عريض، رياضي وكلو حماس وتشويق. صالح للصالات الرياضية، طوموبيلات السفر، المغامرات، ومشروبات الطاقة والجيمنغ.",
    baseVoice: "Fenrir",
    systemTonePrompt: "Speak with a deep, authoritative, and extremely motivating male tone in Moroccan Darija. Urge action with cinematic intensity, quick rhythm and solid clarity."
  }
];

export const MOROCCAN_YOUTH_TEMPLATES: MarketingTemplate[] = [
  {
    id: "streetwear",
    nameEn: "Trendy Local Clothing Brand",
    nameAr: "براند ملابس عصرية للشباب",
    productName: "Zaza Wear Maroc",
    category: "Fashion",
    productDesc: "Over-sized hoodies and streetwear t-shirts made in Casablanca with high quality local materials, perfect for university students and teenagers. Modern minimalist designs.",
    tone: "Trendy & Youthful / Generation-Z (شبابي ومواكب للموضة ومؤثر)",
    customDirectives: "Use cool Moroccan youth slang like 'ناضي', 'ستيل مغربي', 'مكاينش بحالو'. Emphasize Cash on Delivery (الدفع عند الاستلام) across Morocco, and free fast courier delivery to Marrakesh, Casablanca, Rabat and rest of cities.",
    emoji: "👕"
  },
  {
    id: "fastfood",
    nameEn: "Trendy Food Spot / Smash Burger",
    nameAr: "محل برجر عصري واقتصادي",
    productName: "L'Bena Burger",
    category: "Food & Drink",
    productDesc: "Authentic double cheese smash burger with a secret Marrakesh spiced sauce, super crispy fries, and cold soda at a very discount price of 39 DHs for young students.",
    tone: "Energetic and Highly Persuasive (حماسي، جيعان ومقنع)",
    customDirectives: "Use phrases like 'هربان ديال لبنة', 'ثمن ديال الدرويش', 'البنة لي غاتسطيك'. Mention limited time offer today. Highly energetic and mouthwatering delivery vibe.",
    emoji: "🍔"
  },
  {
    id: "mobile_app",
    nameEn: "Modern Freelancer Study App",
    nameAr: "تطبيق لتعليم الديزاين والتجارة",
    productName: "Skilla Academy",
    category: "EdTech App",
    productDesc: "A sleek Moroccan mobile app that teaches youth how to start high-paying graphic design and video editing freelancing in Moroccan Darija, starting from 0 to first sale in 30 days.",
    tone: "Inspirational, Friendly & Professional (ملهم، شبابي وموثوق)",
    customDirectives: "Stress that 'مكاينش شوافرية، بدا خدمتك راسك'. Mention that we have a WhatsApp VIP group for support. Keep it motivating, focusing on financial freedom and simple Moroccan Darija language instructions.",
    emoji: "📱"
  },
  {
    id: "local_ecom",
    nameEn: "Local Smart Gadget / Bluetooth Buds",
    nameAr: "بيع سماعات بلورثوت ذكية",
    productName: "AirPods Pro Max (Maroc Eco)",
    category: "Gadget",
    productDesc: "Premium noise cancelling heavy bass earbuds. Long-lasting 24-hour battery, water-resistant. Best accessory for sports and working out outside or studying in cafes.",
    tone: "High Energy Sales pitch (حماسي ومقنع للبيع السريع)",
    customDirectives: "Accentuate 'ضمانة عام كامل' (1 year warranty) and 'التوصيل فابور حتى للدار' (Free home delivery). Address youth active lifestyle, listening to rap context or calling friends easily.",
    emoji: "🎧"
  }
];
