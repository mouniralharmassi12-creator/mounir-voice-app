export interface VoiceProfile {
  id: string;
  name: string;
  nameAr: string;
  gender: "Male" | "Female";
  tag: string;
  accent: string;
  accentAr: string;
  description: string;
  descriptionAr: string;
  baseVoice: string; // "Kore" | "Puck" | "Zephyr" | "Charon" | "Fenrir"
  systemTonePrompt: string;
  isClone?: boolean;
  cloneSource?: string;
}

export interface MarketingTemplate {
  id: string;
  nameEn: string;
  nameAr: string;
  productName: string;
  category: string;
  productDesc: string;
  tone: string;
  customDirectives: string;
  emoji: string;
}

export interface GeneratedScript {
  darijaScript: string;
  marketingHook: string;
  englishTranslation: string;
  pronunciationTips: string;
  estimatedDuration: string;
}
