import React, { useState, useEffect } from "react";
import {
  Sparkles,
  Volume2,
  Globe,
  Info,
  BookOpen,
  Copy,
  Check,
  Megaphone,
  TrendingUp,
  ArrowRight,
  ChevronRight,
  BadgeAlert,
  CheckCircle,
  FileText,
  HelpCircle,
  Cpu,
  UserCheck,
  RefreshCw
} from "lucide-react";
import { decodePcmToBuffer, playBuffer, pcmBase64ToWavBlob } from "./utils/audio";
import { VoiceProfile, MarketingTemplate, GeneratedScript } from "./types";
import { MOROCCAN_VOICE_MODELS, MOROCCAN_YOUTH_TEMPLATES } from "./data/voices";

import VoiceCloner from "./components/VoiceCloner";
import ScriptGenerator from "./components/ScriptGenerator";
import AudioVisualizer from "./components/AudioVisualizer";

export default function App() {
  // Localization State
  const [lang, setLang] = useState<"en" | "ar">("ar");

  // Voice Actor Configurations
  const [voiceList, setVoiceList] = useState<VoiceProfile[]>(MOROCCAN_VOICE_MODELS);
  const [selectedVoiceId, setSelectedVoiceId] = useState<string>("kenza"); // Kenza is default premium feminine Rabat beauty voice
  
  // Custom Clones state
  const [activeClones, setActiveClones] = useState<VoiceProfile[]>([]);

  // Product Campaign Configuration
  const [productName, setProductName] = useState("Zaza Wear Maroc");
  const [productDesc, setProductDesc] = useState(
    "Over-sized hoodies and streetwear t-shirts made in Casablanca with high quality local materials, perfect for university students and teenagers. Modern minimalist designs."
  );
  const [tone, setTone] = useState("Trendy & Youthful / Generation-Z (شبابي ومواكب للموضة ومؤثر)");
  const [customDirectives, setCustomDirectives] = useState(
    "Use cool Moroccan youth slang like 'ناضي', 'ستيل مغربي', 'مكاينش بحالو'. Emphasize Cash on Delivery (الدفع عند الاستلام) across Morocco, and free fast courier delivery to Marrakesh, Casablanca, Rabat and rest of cities."
  );

  // Psychological triggers checkboxes
  const [includeFreeDelivery, setIncludeFreeDelivery] = useState(true);
  const [includeCashOnDelivery, setIncludeCashOnDelivery] = useState(true);
  const [includeUrgency, setIncludeUrgency] = useState(false);

  // Script Generation State
  const [isGeneratingScript, setIsGeneratingScript] = useState(false);
  const [scriptResponse, setScriptResponse] = useState<GeneratedScript | null>({
    darijaScript: "واش باغي ستيل ناضي لي يفركع هاد الصيف؟ 😎 جرب دابا زازا وير ماروك، جبنا ليك هوديات وكويسات أوفر سايز مخيطين محببين بقطن طبيعي مية في المية في كازا. اللبسة اللّي كتمثلك وكتحمر ليك وجهك قدام لصحاب! الثمن هربان والتوصيل فابور حتى لباب الدار، والدفع حتى تشد كسوتك ولد البلاد. كليكي على الرابط دابا وعمر معلوماتك قبل ما تسالي لكونتيتي! 🚚✨",
    marketingHook: "ستيل مغربي حر ناضي ومريح بزازا وير ماروك! 👕🇲🇦",
    englishTranslation: "Looking for an awesome style that rocks this summer? With Zaza Wear Maroc, we brought you oversized hoodies made with 100% natural Casablawi cotton. A style that represents you in front of friends! Discount price, free delivery straight to your doorstep and Cash on Delivery. Click the link and order now before stock runs out!",
    pronunciationTips: "تنطق 'ناضي' بنبرة حماسية مرتفعة في البداية لجلب الانتباه. كلمة 'هربان' ترمز للجودة الفائقة والثمن المناسب للشباب. احرص على نطق 'كازا' بلكّنة مغربية دارجة أصيلة.",
    estimatedDuration: "25s"
  });
  const [editedScript, setEditedScript] = useState("");

  // Sync edited script to state on new generation
  useEffect(() => {
    if (scriptResponse) {
      setEditedScript(scriptResponse.darijaScript);
    }
  }, [scriptResponse]);

  // Audio Playback states
  const [isGeneratingAudio, setIsGeneratingAudio] = useState(false);
  const [pcmBase64, setPcmBase64] = useState<string | null>(null);
  const [audioBuffer, setAudioBuffer] = useState<AudioBuffer | null>(null);
  const [audioProgress, setAudioProgress] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1.1); // 1.1x is perfect default fast tempo to avoid "heavy voice"

  const [audioController, setAudioController] = useState<{
    pause: () => void;
    resume: () => void;
    stop: () => void;
    setPlaybackRate: (rate: number) => void;
  } | null>(null);

  // Status Alerts
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Get active selected voice profile object
  const activeVoice = voiceList.find((v) => v.id === selectedVoiceId) || voiceList[0];

  const handleApplyTemplate = (tpl: MarketingTemplate) => {
    setProductName(tpl.productName);
    setProductDesc(tpl.productDesc);
    setTone(tpl.tone);
    setCustomDirectives(tpl.customDirectives);

    const targetEl = document.getElementById("generator-workspace");
    if (targetEl) {
      targetEl.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleCloneCreated = (newClone: VoiceProfile) => {
    setVoiceList((prev) => [newClone, ...prev]);
    setActiveClones((prev) => [newClone, ...prev]);
    setSelectedVoiceId(newClone.id);
  };

  const handleDeleteClone = (id: string) => {
    setVoiceList((prev) => prev.filter((v) => v.id !== id));
    setActiveClones((prev) => prev.filter((v) => v.id !== id));
    if (selectedVoiceId === id) {
      setSelectedVoiceId("yasmine");
    }
  };

  // Generate copy script using Gemini Flash
  const handleGenerateScript = async () => {
    setIsGeneratingScript(true);
    setErrorMessage(null);
    setSuccessMessage(null);

    if (audioController) {
      audioController.stop();
      setIsPlaying(false);
      setAudioProgress(0);
    }

    let compoundedDirectives = customDirectives;
    const additionalChecks: string[] = [];
    if (includeFreeDelivery) additionalChecks.push("emphasize Free Delivery (التوصيل فابور)");
    if (includeCashOnDelivery) additionalChecks.push("emphasize Cash On Delivery / Pay on Delivery (الدفع عند الاستلام)");
    if (includeUrgency) additionalChecks.push("stress limited quantities / today only (الكمية محدودة بزاف / غي اليوم)");

    if (additionalChecks.length > 0) {
      compoundedDirectives += `\nStrictly enforce these Moroccan consumer calls to action in Darija Arabic text: ${additionalChecks.join(" AND ")}.`;
    }

    try {
      const resp = await fetch("/api/generate-script", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          productName,
          productDesc,
          tone,
          customDirectives: compoundedDirectives
        })
      });

      if (!resp.ok) {
        throw new Error(`HTTP ${resp.status}: Could not generate copy script.`);
      }

      const data: GeneratedScript = await resp.json();
      setScriptResponse(data);
      setSuccessMessage(
        lang === "ar" 
          ? "رائع! تم توليد السيناريو بأسلوب مغربي حقيقي وتناقل لافت." 
          : "Superb! High converting marketing script successfully written!"
      );
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || "Could not connect to script generator service.");
    } finally {
      setIsGeneratingScript(false);
    }
  };

  // Convert script copy to audio using Gemini TTS
  const handleGenerateAudio = async () => {
    if (!editedScript.trim()) {
      setErrorMessage(lang === "ar" ? "يرجى صياغة السيناريو أولاً قبل التوليد الصوتي." : "Please write or generate script first.");
      return;
    }

    setIsGeneratingAudio(true);
    setErrorMessage(null);
    setSuccessMessage(null);
    setPcmBase64(null);
    setAudioBuffer(null);
    setAudioProgress(0);

    if (audioController) {
      audioController.stop();
      setIsPlaying(false);
    }

    try {
      const resp = await fetch("/api/generate-audio", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          scriptText: editedScript,
          voiceName: activeVoice.baseVoice,
          toneGuide: tone,
          voiceTonePrompt: activeVoice.systemTonePrompt
        })
      });

      if (!resp.ok) {
        const errorText = await resp.text();
        throw new Error(`TTS Error: ${errorText || "Error synthesizing audio signal."}`);
      }

      const result = await resp.json();
      if (!result.base64Audio) {
        throw new Error("No voiceover PCM data returned from server.");
      }

      setPcmBase64(result.base64Audio);

      const decoded = await decodePcmToBuffer(result.base64Audio, 24000);
      setAudioBuffer(decoded);
      setSuccessMessage(
        lang === "ar" 
          ? `تم رصد وتأهيل صوت المعلق "${lang === "ar" ? activeVoice.nameAr : activeVoice.name}" بنجاح فائق! اضغط الاستماع بالأسفل.` 
          : `Voice actor ${activeVoice.name} successfully loaded. Ready to play.`
      );
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || "Error synthesizing Moroccan voiceover WAV signal.");
    } finally {
      setIsGeneratingAudio(false);
    }
  };

  // Toggle Audio Playback
  const handleTogglePlayback = () => {
    if (!audioBuffer) return;

    if (isPlaying) {
      if (audioController) {
        audioController.pause();
        setIsPlaying(false);
      }
    } else {
      if (audioController) {
        audioController.resume();
        setIsPlaying(true);
      } else {
        const controller = playBuffer(
          audioBuffer,
          (progress, playing) => {
            setAudioProgress(progress);
            setIsPlaying(playing);
          },
          () => {
            setIsPlaying(false);
            setAudioController(null);
          }
        );
        controller.setPlaybackRate(playbackSpeed);
        setAudioController(controller);
        setIsPlaying(true);
      }
    }
  };

  // Stop Audio Playback
  const handleStopPlayback = () => {
    if (audioController) {
      audioController.stop();
      setAudioController(null);
    }
    setIsPlaying(false);
    setAudioProgress(0);
  };

  // Update speed
  const handleSpeedChange = (speed: number) => {
    setPlaybackSpeed(speed);
    if (audioController) {
      audioController.setPlaybackRate(speed);
    }
  };

  // Download Audio as .wav format
  const handleDownloadWav = () => {
    if (!pcmBase64) return;
    try {
      const blob = pcmBase64ToWavBlob(pcmBase64, 24000);
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      const safeName = productName.toLowerCase().replace(/[^a-z0-9]/g, "_") || "darija";
      a.download = `${safeName}_${activeVoice.id}_darija_marketing_ad.wav`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error("Failed to generate WAV download", err);
    }
  };

  // Clipboard managers
  const [copiedScript, setCopiedScript] = useState(false);
  const [copiedHook, setCopiedHook] = useState(false);

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans selection:bg-rose-600 selection:text-white antialiased">
      
      {/* Dynamic Header */}
      <header className="border-b border-neutral-800 bg-neutral-900/80 backdrop-blur-md sticky top-0 z-40 px-4 py-3.5">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-rose-600 to-amber-500 flex items-center justify-center shadow-lg shadow-rose-950/25">
              <Megaphone className="w-5.5 h-5.5 text-neutral-950 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-extrabold uppercase tracking-widest text-rose-500 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20">
                  Darija Ads Studio 🇲🇦
                </span>
              </div>
              <h1 className="text-sm font-extrabold text-neutral-50 tracking-tight">صوت التسويق بالدارجة المغربية للمحترفين</h1>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setLang(lang === "en" ? "ar" : "en")}
              className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl border border-neutral-700 bg-neutral-800 hover:bg-neutral-750 text-xs text-neutral-300 font-bold cursor-pointer transition-all"
            >
              <Globe className="w-3.5 h-3.5 text-rose-500" />
              <span>{lang === "en" ? "العربية المغربية (Dar)" : "English UI"}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Grid Content Area */}
      <main className="flex-1 max-w-7xl mx-auto w-full p-4 lg:p-8 grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8">
        
        {/* LEFT COLUMN: Setup Configurations & Templates / Cloner */}
        <section className="lg:col-span-12 xl:col-span-7 flex flex-col gap-6">
          
          {/* Welcome Intro Banner */}
          <div className="rounded-2xl border border-neutral-800 p-6 bg-gradient-to-br from-neutral-900 via-neutral-900/90 to-rose-950/20 shadow-xl relative overflow-hidden">
            <div className="absolute right-0 top-0 -mt-10 -mr-10 w-44 h-44 bg-gradient-to-br from-rose-500 to-amber-500 rounded-full blur-3xl opacity-15 pointer-events-none"></div>

            <div className="flex flex-col gap-3">
              <h2 className="text-2xl font-black tracking-tight bg-gradient-to-r from-rose-400 via-amber-400 to-rose-300 bg-clip-text text-transparent">
                {lang === "ar" 
                  ? "مولد إشهاري ذكي بالدارجة المغربية الحية" 
                  : "Authentic Moroccan Darija Voice & Ad Copy Studio"}
              </h2>

              <p className="text-xs text-neutral-300 leading-relaxed font-medium">
                {lang === "ar"
                  ? "حقق المزيد من المبيعات لإعلانات التجارة الإلكترونية، الدروبشيبينغ، الريلز وتيك توك بالمغرب! تطبيقنا يقوم بكتابة سيناريو مدروس سيكولوجياً لجمهور الشباب وتحويله ميكانيكياً لأصوات طبيعية، سريعة، وماركتينغ خفيفة تماماً ومطابقة لـ 15 معلقاً مختلفاً أو عبر استنساخ صوتك المفضل."
                  : "Double your sales across Morocco, and target Gen-Z viewers on Instagram Reels & TikTok. Craft high-converting Darija ads automatically with light-paced, dynamic Moroccan voice models or use our Social Media Voice Cloner Lab below."}
              </p>

              <div className="flex flex-wrap gap-2 mt-1">
                <span className="inline-flex items-center gap-1 text-[10px] uppercase font-bold text-rose-300 bg-rose-500/10 px-2.5 py-1 rounded-full border border-rose-600/20">
                  🔥 {lang === "ar" ? "إقناع سيكولوجي مدمج" : "Psychology Copywriting"}
                </span>
                <span className="inline-flex items-center gap-1 text-[10px] uppercase font-bold text-amber-300 bg-amber-500/10 px-2.5 py-1 rounded-full border border-amber-600/20">
                  🎙️ {lang === "ar" ? "15 معلقاً + استنساخ فوري" : "15 Voice Models + Clones"}
                </span>
                <span className="inline-flex items-center gap-1 text-[10px] uppercase font-bold text-neutral-400 bg-neutral-900 px-2.5 py-1 rounded-full border border-neutral-800">
                  ⚡ {lang === "ar" ? "صوت خفيف وسريع غير ثقيل" : "Fast & Light Tempos"}
                </span>
              </div>
            </div>
          </div>

          {/* Quick Preset Campaign Templates Selection */}
          <div className="flex flex-col gap-3">
            <span className="text-[11px] font-bold tracking-wider text-neutral-400 uppercase flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5 text-rose-500" />
              {lang === "ar" ? "اختر قالب مبيعات سريع لتجربته دابا" : "Pick a high-performing local campaign template"}
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {MOROCCAN_YOUTH_TEMPLATES.map((tpl) => (
                <button
                  key={tpl.id}
                  onClick={() => handleApplyTemplate(tpl)}
                  className="group relative flex flex-col items-start gap-2 p-4 rounded-xl border border-neutral-800 bg-neutral-900/40 text-left hover:border-rose-500/40 hover:bg-neutral-900 transition-all cursor-pointer shadow-sm"
                >
                  <div className="absolute right-3 top-3 text-lg group-hover:scale-125 transition-transform">{tpl.emoji}</div>
                  <span className="text-[9px] font-extrabold uppercase text-rose-400 bg-rose-500/5 px-2 py-0.5 rounded tracking-wide border border-rose-500/10">
                    {tpl.category}
                  </span>
                  <div className="mt-1">
                    <h4 className="text-xs font-bold text-neutral-100 group-hover:text-rose-400 transition-colors">
                      {lang === "ar" ? tpl.nameAr : tpl.nameEn}
                    </h4>
                    <p className="text-[10px] text-neutral-400 line-clamp-2 mt-1 leading-relaxed">
                      {tpl.productDesc}
                    </p>
                  </div>
                  <div className="mt-1.5 flex items-center gap-1 text-[10px] font-extrabold text-neutral-300 group-hover:text-white transition-all">
                    <span>{lang === "ar" ? "اضغط دابا و جرب" : "Apply to Workspace"}</span>
                    <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Script specifications workspace */}
          <ScriptGenerator
            lang={lang}
            productName={productName}
            setProductName={setProductName}
            productDesc={productDesc}
            setProductDesc={setProductDesc}
            tone={tone}
            setTone={setTone}
            customDirectives={customDirectives}
            setCustomDirectives={setCustomDirectives}
            includeFreeDelivery={includeFreeDelivery}
            setIncludeFreeDelivery={setIncludeFreeDelivery}
            includeCashOnDelivery={includeCashOnDelivery}
            setIncludeCashOnDelivery={setIncludeCashOnDelivery}
            includeUrgency={includeUrgency}
            setIncludeUrgency={setIncludeUrgency}
            isGeneratingScript={isGeneratingScript}
            onGenerateScript={handleGenerateScript}
          />

          {/* Elegant Voice Cloner Workspace */}
          <VoiceCloner
            lang={lang}
            onCloneCreated={handleCloneCreated}
            activeClones={activeClones}
            onDeleteClone={handleDeleteClone}
          />

        </section>

        {/* RIGHT COLUMN: Results, 15 Voice Models Directory, Playback Controls */}
        <section className="lg:col-span-12 xl:col-span-5 flex flex-col gap-6">
          
          {/* Notifications and messages UI block */}
          {errorMessage && (
            <div className="rounded-xl border border-rose-500/20 bg-rose-500/10 p-4 text-xs text-rose-300 flex items-start gap-2.5 shadow-md">
              <BadgeAlert className="w-4.5 h-4.5 text-rose-500 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold block mb-0.5">{lang === "ar" ? "تنبيـه" : "System Notification"}</span>
                <span className="font-medium">{errorMessage}</span>
              </div>
            </div>
          )}

          {successMessage && (
            <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/10 p-4 text-xs text-emerald-300 flex items-start gap-2.5 shadow-md">
              <CheckCircle className="w-4.5 h-4.5 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold block mb-0.5">{lang === "ar" ? "نجاح العملية" : "Success"}</span>
                <span className="font-medium">{successMessage}</span>
              </div>
            </div>
          )}

          {/* Output Script Copy result pane */}
          <div className="rounded-2xl border border-neutral-800 bg-neutral-900 shadow-xl overflow-hidden flex flex-col">
            <div className="bg-neutral-850 p-4 border-b border-neutral-800/80 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-rose-500" />
                <h3 className="font-bold text-neutral-100 text-xs uppercase tracking-wider">
                  {lang === "ar" ? "السيناريو الإشهاري المتولد" : "Interactive Copywritten Script"}
                </h3>
              </div>
              {scriptResponse && (
                <span className="text-[10px] font-bold text-rose-400 bg-rose-500/10 px-2.5 py-0.5 rounded border border-rose-500/20">
                  ⏱️ {scriptResponse.estimatedDuration || "30s"}
                </span>
              )}
            </div>

            <div className="p-4 flex flex-col gap-4">
              
              {/* Marketing Tagline preview hook */}
              {scriptResponse && (
                <div className="bg-rose-500/5 rounded-xl border border-rose-500/10 p-3.5 flex flex-col gap-1 relative group">
                  <span className="text-[9px] font-black uppercase text-rose-400 tracking-widest">
                    {lang === "ar" ? "جملة التعليق المعلقة أو الإعلان السريع" : "Promo Hook Line / Visual Tagline"}
                  </span>
                  <p className="text-xs font-extrabold text-amber-200 text-right dir-rtl mt-0.5 leading-relaxed">{scriptResponse.marketingHook}</p>
                  
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(scriptResponse.marketingHook);
                      setCopiedHook(true);
                      setTimeout(() => setCopiedHook(false), 2500);
                    }}
                    className="absolute right-2.5 top-2.5 p-1.5 rounded-lg bg-neutral-950/70 hover:bg-neutral-950 text-neutral-400 hover:text-white transition-all cursor-pointer opacity-0 group-hover:opacity-100"
                    title="Copy Tagline"
                  >
                    {copiedHook ? <Check className="w-3.5 h-3.5 text-emerald-450" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              )}

              {/* Editable Darija Voice script text area */}
              <div className="flex flex-col gap-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] font-black uppercase tracking-wider text-neutral-400">
                    {lang === "ar" ? "نص الإلقاء بالدارجة المغربية (اضغط للتعديل)" : "Spoken Script (Directly editable)"}
                  </label>
                  {editedScript && (
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(editedScript);
                        setCopiedScript(true);
                        setTimeout(() => setCopiedScript(false), 2500);
                      }}
                      className="text-[10px] text-rose-400 hover:text-rose-300 font-bold flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      {copiedScript ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span>{lang === "ar" ? "تم نسخ السيناريو" : "Copied!"}</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>{lang === "ar" ? "نسخ السيناريو" : "Copy Script Text"}</span>
                        </>
                      )}
                    </button>
                  )}
                </div>

                <div className="relative">
                  <textarea
                    id="script-editor"
                    rows={5}
                    value={editedScript}
                    onChange={(e) => setEditedScript(e.target.value)}
                    dir="rtl"
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-4 text-xs font-semibold text-neutral-200 hover:border-neutral-750 focus:border-rose-500 transition-all leading-relaxed text-right font-arabic selection:bg-rose-650"
                  />
                  <div className="absolute left-3 bottom-3 text-[9px] font-mono text-neutral-500">
                    {editedScript.length} {lang === "ar" ? "حرف" : "chars"}
                  </div>
                </div>
              </div>

              {/* Pronunciation tips module */}
              {scriptResponse && (
                <div className="flex flex-col gap-1.5">
                  <span className="text-[10px] font-black uppercase tracking-wider text-neutral-400 flex items-center gap-1.5">
                    <BookOpen className="w-3.5 h-3.5 text-rose-500" />
                    {lang === "ar" ? "دليل نبرات الإلقاء وطريقة نطق الكلمات" : "Stressing Tips & Dialect Flow Guidance"}
                  </span>
                  <div className="rounded-xl border border-neutral-800 bg-neutral-950 p-3 text-[11px] font-medium text-neutral-300 text-right leading-relaxed dir-rtl">
                    {scriptResponse.pronunciationTips}
                  </div>
                </div>
              )}

              {/* English summaries for client reference */}
              {scriptResponse && (
                <div className="bg-neutral-950 rounded-xl p-3 border border-neutral-850">
                  <span className="text-[9px] font-black tracking-wider uppercase text-neutral-400 block mb-1">
                    🇬🇧 English Summary of the Darija Script
                  </span>
                  <p className="text-xs text-neutral-400 italic leading-relaxed">
                    "{scriptResponse.englishTranslation}"
                  </p>
                </div>
              )}

            </div>
          </div>

          {/* 15 Voice Models Directory Selection and TTS Generation */}
          <div className="rounded-2xl border border-neutral-800 bg-neutral-900 shadow-xl overflow-hidden flex flex-col" id="voice-actors-workspace">
            <div className="bg-neutral-850 p-4 border-b border-neutral-800/80 flex items-center justify-between">
              <div className="flex flex-col">
                <div className="flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-rose-500" />
                  <h3 className="font-bold text-neutral-100 text-xs uppercase tracking-wider">
                    {lang === "ar" ? "سجل المعلقين الصوتيين (15 معلقاً مميزاً)" : "The Moroccan Voice Profiles Directory"}
                  </h3>
                </div>
              </div>
              <span className="text-[9px] uppercase tracking-wider font-extrabold text-rose-400 bg-rose-500/10 border border-rose-500/20 px-2 py-0.5 rounded">
                {voiceList.length} Active Voices
              </span>
            </div>

            {/* List with height limit for scannable scroll */}
            <div className="p-4 flex flex-col gap-3.5">
              
              <div className="flex flex-col gap-1.5">
                <span className="text-[10px] font-black uppercase text-neutral-400 tracking-wider">
                  {lang === "ar" ? "اختر صوت المعلق المناسب لسلعتك أو خدمتك" : "Select Your Representative Brand Voice"}
                </span>

                <div className="max-h-[310px] overflow-y-auto pr-1 flex flex-col gap-2 scrollbar-thin scrollbar-thumb-neutral-800 scrollbar-track-transparent">
                  {voiceList.map((model) => {
                    const isSelected = selectedVoiceId === model.id;
                    const isFemale = model.gender === "Female";

                    return (
                      <div
                        key={model.id}
                        onClick={() => setSelectedVoiceId(model.id)}
                        className={`flex flex-col p-3 rounded-xl border text-left cursor-pointer transition-all ${
                          isSelected
                            ? "border-rose-500 bg-rose-500/5 shadow-md shadow-rose-950/10"
                            : "border-neutral-850 bg-neutral-950/50 hover:bg-neutral-900 hover:border-neutral-800"
                        }`}
                        id={`voice-box-${model.id}`}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-2">
                            <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm ${
                              isFemale 
                                ? "bg-purple-500/10 text-purple-400" 
                                : "bg-blue-500/10 text-blue-400"
                            }`}>
                              {isFemale ? "👩" : "👨"}
                            </div>
                            <div>
                              <div className="flex items-center gap-1.5">
                                <span className={`text-xs font-black ${isSelected ? "text-rose-400" : "text-neutral-100"}`}>
                                  {lang === "ar" ? model.nameAr : model.name}
                                </span>
                                {model.isClone && (
                                  <span className="text-[8px] uppercase tracking-wider px-1 bg-rose-500/20 rounded font-bold text-rose-300">
                                    Clone
                                  </span>
                                )}
                              </div>
                              <span className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block mt-0.5">
                                {model.accent} • {model.tag}
                              </span>
                            </div>
                          </div>

                          <span className={`text-[9px] font-extrabold uppercase px-2 py-0.5 rounded-full ${
                            isFemale
                              ? "bg-purple-550/15 text-purple-400 border border-purple-500/20"
                              : "bg-blue-550/15 text-blue-400 border border-blue-500/20"
                          }`}>
                            {isFemale ? (lang === "ar" ? "أنثى" : "Female") : (lang === "ar" ? "ذكر" : "Male")}
                          </span>
                        </div>

                        {/* Description */}
                        <p className={`text-[11px] leading-relaxed mt-2 text-right dir-rtl font-medium ${
                          isSelected ? "text-neutral-105" : "text-neutral-400"
                        }`}>
                          {lang === "ar" ? model.descriptionAr : model.description}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Synthesize triggering CTA */}
              <button
                id="btn-synthesize-comp"
                onClick={handleGenerateAudio}
                disabled={isGeneratingAudio || !editedScript.trim()}
                className="w-full bg-rose-600 hover:bg-rose-500 text-white font-black text-xs py-3.5 px-6 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-rose-950/30 active:scale-[0.99] transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
              >
                {isGeneratingAudio ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-white" />
                    <span>
                      {lang === "ar" 
                        ? `جاري هندسة وتوليد صوت المعلق "${lang === "ar" ? activeVoice.nameAr : activeVoice.name}"...` 
                        : `Synthesizing ${activeVoice.name}'s voice template...`}
                    </span>
                  </>
                ) : (
                  <>
                    <Volume2 className="w-4.5 h-4.5 text-white" />
                    <span>
                      {lang === "ar" 
                        ? `ولّد دابا التعليق الصوتي بصوت [${lang === "ar" ? activeVoice.nameAr : activeVoice.name}] 🎙️` 
                        : `Synthesize Voiceover in ${activeVoice.name}'s Tone Now`}
                    </span>
                  </>
                )}
              </button>

              {/* WAV Studio Playback */}
              <AudioVisualizer
                lang={lang}
                isPlaying={isPlaying}
                audioProgress={audioProgress}
                audioBuffer={audioBuffer}
                playbackSpeed={playbackSpeed}
                onSpeedChange={handleSpeedChange}
                onTogglePlayback={handleTogglePlayback}
                onStopPlayback={handleStopPlayback}
                onDownloadWav={handleDownloadWav}
                pcmBase64={pcmBase64}
                isGeneratingAudio={isGeneratingAudio}
                selectedVoice={lang === "ar" ? activeVoice.nameAr : activeVoice.name}
              />

            </div>
          </div>

        </section>

      </main>

      {/* Footer footer */}
      <footer className="border-t border-neutral-800 bg-neutral-900/40 py-6 px-4 mt-8">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-500 font-semibold">
          <span>🇲🇦 {lang === "ar" ? "صنع بحب للمسوقين والشباب المغربي للتجارة الالكترونية" : "Made in Casablanca & Rabat for elegant Moroccan E-com Ads."}</span>
          <span className="font-mono text-[10px] text-rose-500/70">Powered by Gemini Pro & Google AI Studio Applet Engine</span>
        </div>
      </footer>
    </div>
  );
}
